// Task: Find and correct possible issues in the following code.

//Test Program personType
  
#include <iostream>  
#include <string>
#include "personType.hpp" 
 
using namespace std;

int main()
{
    personType student("Lisa", "Regan");

    student.print();

    cout << endl;

    return 0;
}
