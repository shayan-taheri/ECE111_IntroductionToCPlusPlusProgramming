// Task: Find and correct possible issues in the following code.
    
#include <iostream>
#include "illustrate.hpp" 

using namespace std;

float illustrate::count = 0;
char illustrate::y = 0;

void illustrate::print() const
{
    cout << "x = " << x << ", y = " << y
         << ", count = " << count << endl;
}

void illustrate::setX(int a)
{
    x = a;
}

void illustrate::incrementY()
{
    y++;
}

illustrate::illustrate(int a)
{ 
    x = a;
}
